<?php

namespace App\Models;

class PasswordReset extends Model
{
    protected $connection = 'default';
    protected $table = 'ss_password_reset';
}
