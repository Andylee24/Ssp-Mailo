1：下载app

![](/images/c_android_1.jpg)

2：添加订阅并更新

![](/images/c_android_2.jpg)

![](/images/c_android_3.jpg)

![](/images/c_android_4.jpg)

![](/images/c_android_5.jpg)

3：选择一个节点并设置路由

![](/images/c_android_6.jpg)

![](/images/c_android_7.jpg)

4：连接

![](/images/c_android_8.jpg)

注释：国产安卓系统为定制系统，如需要Youtube、Google套件等，需要安装Google框架，具体机型如何安装各不相同，请直接查找教程