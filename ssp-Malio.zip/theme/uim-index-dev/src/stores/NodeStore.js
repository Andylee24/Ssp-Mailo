export default {
  state: {
    nodeList: ''
  },
  mutations: {
    SET_NODELIST(state, config) {
      state.nodeList = config
    }
  },
  actions: {

  }
}
